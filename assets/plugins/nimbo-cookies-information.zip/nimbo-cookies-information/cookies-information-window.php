<?php
/**
 * "Cookies Information" Window
 *
 * @since Nimbo Cookies Information 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function nimbo_cookies_information_window() {

	// "cookies information" window: show or hide
	$show_cookies_info = get_theme_mod( 'nimbo_show_cookies_info', 0 ); // 1 or 0
	// "cookies information" window status: "yes", if the "Accept" button was pressed, otherwise "no"
	$cookies_accepted = ( ! empty( $_COOKIE['nimbo_cookies_accepted'] ) ) ? $_COOKIE['nimbo_cookies_accepted'] : 'no'; // 'yes' or 'no'

	if ( $show_cookies_info && 'yes' !== $cookies_accepted ) {

		// "cookies information" window: text
		$cookies_info_text = get_theme_mod( 'nimbo_cookies_info_text', 'Our website use cookies. If you continue to use this site we will assume that you are happy with this.' );
		// "cookies information" window: accept button text
		$cookies_accept_btn_text = get_theme_mod( 'nimbo_cookies_accept_btn_text', 'Accept' );

		if ( $cookies_info_text && $cookies_accept_btn_text ) {

			// "cookies information" window: window type on mobile devices
			$cookies_info_on_mobile = get_theme_mod( 'nimbo_cookies_info_on_mobile', 'hidden-window' ); // 'hidden-window' or 'visible-window'
			?>

			<!-- "cookies information" window -->
			<div id="bwp-cookies-info" class="bwp-cookies-info-container clearfix<?php if ( 'hidden-window' === $cookies_info_on_mobile ) { echo ' bwp-hidden-on-mobile'; } else { echo ' bwp-visible-on-mobile'; } ?>">

				<?php if ( 'hidden-window' === $cookies_info_on_mobile ) { ?>
					<!-- close icon (for mobile devices) -->
					<div id="bwp-close-cookies-info" class="bwp-cookies-close-icon">
						<i class="fas fa-times"></i>
					</div>
					<!-- end: close icon (for mobile devices) -->
				<?php } ?>

				<!-- info icon -->
				<div class="bwp-cookies-info-icon">
					<i class="fas fa-info"></i>
				</div>
				<!-- end: info icon -->

				<!-- content -->
				<div class="bwp-cookies-info-content">
					<?php
					echo wp_kses( $cookies_info_text, array(
						'p'			=> array(
							'class'		=> array()
						),
						'a'			=> array(
							'href'		=> array(),
							'title'		=> array(),
							'target'	=> array(),
							'class'		=> array(),
							'rel'		=> array(),
						),
						'span'		=> array(
							'class'		=> array()
						),
						'strong'	=> array(),
						'b'			=> array(),
						'em'		=> array(),
						'i'			=> array(
							'class'		=> array()
						),
						'br'		=> array(),
					) );
					?>
				</div>
				<!-- end: content -->

				<!-- "accept cookies" button -->
				<button type="button" id="bwp-accept-cookies" class="bwp-accept-cookies-btn">
					<?php
					echo esc_html( $cookies_accept_btn_text );
					?>
				</button>
				<!-- end: "accept cookies" button -->

			</div>
			<!-- end: "cookies information" window -->

			<?php
			if ( 'hidden-window' === $cookies_info_on_mobile ) {
				?>

				<!-- info icon (for mobile devices) -->
				<div id="bwp-show-cookies-info" class="bwp-mobile-cookies-info-icon">
					<i class="fas fa-info"></i>
				</div>
				<!-- end: info icon (for mobile devices) -->

				<?php
			}

		}

	}

}
