/**
 * Plugin name: Nimbo Cookies Information
 * nimbo-cookies-information-plugin.js v1.1.0
 */

( function( $ ) {
	'use strict';
	$( document ).ready( function() {

		var	$cookiesInfo = $( '#bwp-cookies-info' ),
			cookieAccepted = 'nimbo_cookies_accepted'; // cookie name; this cookie is used to store the status of the "Cookies information" window: "Yes", if the "Accept" button was pressed, otherwise "No";


		/**
		 * "Cookies information" window
		 * ----------------------------------------------------
		 */

		// function: accept cookies
		function acceptCookies() {

			var $acceptCookiesButton = $( '#bwp-accept-cookies' );

			// click on the button
			$acceptCookiesButton.on( 'click', function() {
				// hide "cookies information" window
				hideCookiesInfo();
				// set cookie (we must remember that the user agrees to accept cookies)
				setCookie( cookieAccepted, 'yes' );
			} );

		}

		// function: hide "cookies information" window
		function hideCookiesInfo() {

			// hide the window
			$cookiesInfo.addClass( 'bwp-hidden' );
			setTimeout( function() {
				$cookiesInfo.css( 'display', 'none' );
			}, 200 );

		}

		// accept cookies: start function
		acceptCookies();

		// delete cookie if window is hidden
		if ( 'hide' === nimboCookiesInformationData.cookiesInfoWindow ) {
			if ( getCookie( cookieAccepted ) ) {
				deleteCookie( cookieAccepted );
			}
		}


		/**
		 * "Cookies information" window (for mobile devices)
		 * ----------------------------------------------------
		 */

		// function: show or hide "cookies information" window on mobile devices
		function showHideCookiesInfoMobile() {

			var	$showCookiesInfo = $( '#bwp-show-cookies-info' ),
				$closeCookiesInfo = $( '#bwp-close-cookies-info' ),
				hiddenClass = 'bwp-hidden-on-mobile';

			// info icon: click
			$showCookiesInfo.on( 'click', function() {

				// if the window is hidden
				if ( $cookiesInfo.hasClass( hiddenClass ) ) {

					// show "cookies information" window with close icon
					$cookiesInfo.css( 'display', 'block' );
					setTimeout( function() {
						$cookiesInfo.removeClass( hiddenClass );
					}, 4 );

					// hide info icon
					$showCookiesInfo.addClass( hiddenClass );

				}

			} );

			// close icon: click
			$closeCookiesInfo.on( 'click', function() {

				// hide "cookies information" window with close icon
				$cookiesInfo.addClass( hiddenClass );
				setTimeout( function() {
					$cookiesInfo.attr( 'style', '' ); // remove "display: block" style
				}, 200 );

				// show info icon
				$showCookiesInfo.removeClass( hiddenClass );

			} );

		}

		// show or hide "cookies information" window on mobile devices: start function
		if ( 'hidden-window' === nimboCookiesInformationData.cookiesInfoOnMobile ) {
			showHideCookiesInfoMobile();
		}


		/**
		 * Cookie: set cookie, get cookie, and delete cookie
		 * ----------------------------------------------------
		 */

		// function: set cookie
		function setCookie( name, value ) {

			// cookie value
			value = encodeURIComponent( value );

			// expiration date (+60 days)
			var date = new Date;
			date.setDate( date.getDate() + 60 );

			// set cookie
			document.cookie = name + '=' + value + '; path=/; expires=' + date.toUTCString();

		}

		// function: get cookie
		function getCookie( name ) {

			var matches = document.cookie.match( new RegExp(
				"(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
			) );

			return matches ? decodeURIComponent( matches[1] ) : undefined;

		}

		// function: delete cookie
		function deleteCookie( name ) {

			// set the date in the past
			var date = new Date;
			date.setDate( date.getDate() - 1 );

			// delete cookie
			document.cookie = name + '=; path=/; expires=' + date.toUTCString();

		}

	} );
} )( jQuery );
