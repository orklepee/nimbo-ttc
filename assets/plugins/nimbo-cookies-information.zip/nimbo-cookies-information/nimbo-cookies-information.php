<?php
/*
Plugin Name:	Nimbo Cookies Information
Plugin URI:		https://themeforest.net/user/birdwpthemes
Description:	This plugin displays a window with information about cookies on the site.
Version:		1.1
Author:			Alexey Trofimov
Author URI:		https://themeforest.net/user/birdwpthemes
License:		GPL2
License URI:	https://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Define some constants
 *
 * @since Nimbo Cookies Information 1.0
 */
define( 'NIMBO_COOKIES_INFORMATION_DIR', plugin_dir_path( __FILE__ ) );
define( 'NIMBO_COOKIES_INFORMATION_URL', plugin_dir_url( __FILE__ ) );


/**
 * Enqueue scripts
 *
 * @since Nimbo Cookies Information 1.0
 */
function nimbo_cookies_information_scripts() {

	// nimbo cookies information: js
	wp_enqueue_script( 'nimbo-cookies-information-plugin', NIMBO_COOKIES_INFORMATION_URL . 'js/nimbo-cookies-information-plugin.js', array( 'jquery' ), '1.1.0', true );

	// add some data to the main js file
	// "cookies information" window: show or hide
	$show_cookies_info = get_theme_mod( 'nimbo_show_cookies_info', 0 ); // 1 or 0
	$cookiesInfoWindow_data = ( $show_cookies_info ) ? 'show' : 'hide';

	// "cookies information" window: window type on mobile devices
	$cookies_info_on_mobile = get_theme_mod( 'nimbo_cookies_info_on_mobile', 'hidden-window' ); // 'hidden-window' or 'visible-window'

	$nimboCookiesInformationData_array = array(
		'cookiesInfoWindow'		=> $cookiesInfoWindow_data,
		'cookiesInfoOnMobile'	=> $cookies_info_on_mobile,
	);
	wp_localize_script( 'nimbo-cookies-information-plugin', 'nimboCookiesInformationData', $nimboCookiesInformationData_array );

}
add_action( 'wp_enqueue_scripts', 'nimbo_cookies_information_scripts' );


/**
 * "Cookies Information" Window
 *
 * @since Nimbo Cookies Information 1.0
 */
require_once NIMBO_COOKIES_INFORMATION_DIR . 'cookies-information-window.php';
