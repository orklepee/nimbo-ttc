=== Nimbo Cookies Information ===
Contributors: BirdwpThemes
Tags: cookie, cookies, information, window
Requires at least: WordPress 4.9.x
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin displays a window with information about cookies on the site.

== Changelog ==
Version 1.1
- Added: New window type for mobile devices

Version 1.0
- Release
