<?php
/**
 * Registering meta boxes
 *
 * @since Nimbo Social Media 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rwmb_meta_boxes', 'nimbo_social_media_meta_boxes' );

function nimbo_social_media_meta_boxes( $meta_boxes ) {

	$prefix = 'nimbo_social_media_';

	/**
	 * Pages meta boxes
	 *
	 * @since Nimbo Social Media 1.0
	 */
	$meta_boxes[] = array(
		'id'		=> "{$prefix}page_social_share_buttons",
		'title'		=> esc_html__( 'Social Share Buttons', 'nimbo-social-media' ),
		'pages'		=> array( 'page' ),
		'context'	=> 'normal',
		'priority'	=> 'low',
		'fields'	=> array(

			/**
			 * Show or hide social share buttons
			 *
			 * @since Nimbo Social Media 1.0
			 */
			array(
				'name'		=> esc_html__( 'Social share buttons: Show or hide', 'nimbo-social-media' ),
				'desc'		=> esc_html__( 'Default value: Show', 'nimbo-social-media' ),
				'id'		=> "{$prefix}page_show_share_buttons",
				'type'		=> 'select_advanced',
				'options'	=> array(
					'show'	=> esc_html__( 'Show', 'nimbo-social-media' ),
					'hide'	=> esc_html__( 'Hide', 'nimbo-social-media' ),
				),
				'std'			=> 'show',
				'multiple'		=> false,
				'placeholder'	=> esc_html__( 'Show / Hide', 'nimbo-social-media' ),
			),

		),
	);

	return $meta_boxes;

}
