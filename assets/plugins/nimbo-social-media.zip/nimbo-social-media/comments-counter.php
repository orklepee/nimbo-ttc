<?php
/**
 * Comments counter
 *
 * @since Nimbo Social Media 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function nimbo_social_media_comments_counter() {
	?>

	<a href="#comments" rel="nofollow">
		<i class="far fa-comment"></i><span class="bwp-count"><?php comments_number( '0', '1', '%' ); ?></span>
	</a>

	<?php
}
