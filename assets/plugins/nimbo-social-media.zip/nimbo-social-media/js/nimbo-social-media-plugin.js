/**
 * Plugin name: Nimbo Social Media
 * nimbo-social-media-plugin.js v1.0.0
 */

( function( $ ) {
	'use strict';
	$( document ).ready( function() {

		/**
		 * "I like" counter
		 * ----------------------------------------------------
		 */

		// function: update like counter
		function updateLikeCounter() {

			var $likeIcon = $( '.bwp-post-like-icon a' );

			// like icon: click
			$likeIcon.on( 'click', function( e ) {
				e.preventDefault();

				var	$thisLikeIcon = $( this ),
					postId = $thisLikeIcon.data( 'post_id' );

				$.ajax( {
					type: 'POST',
					url: nimboSocialMediaData.ajaxURL,
					data: {
						action: 'nimbo-social-media-like',
						nonce: nimboSocialMediaData.ajaxNonce,
						nimbo_social_media_like: '',
						post_id: postId
					},
					success: function( count ) {
						if ( -1 !== count.indexOf( 'already' ) ) {
							var intCount = count.replace( 'already', '' );
							if ( 0 === intCount ) {
								intCount = '0';
							}
							$thisLikeIcon.children( '.bwp-like' ).removeClass( 'bwp-pastliked bwp-prevliked' ).addClass( 'bwp-disliked' ).html( '<i class="far fa-heart"></i>' );
							$thisLikeIcon.children( '.bwp-count' ).removeClass( 'bwp-liked bwp-alreadyliked' ).addClass( 'bwp-disliked' ).text( intCount );
						} else {
							$thisLikeIcon.children( '.bwp-like' ).addClass( 'bwp-pastliked' ).removeClass( 'bwp-disliked' ).html( '<i class="fas fa-heart"></i>' );
							$thisLikeIcon.children( '.bwp-count' ).addClass( 'bwp-liked' ).removeClass( 'bwp-disliked' ).text( count );
						}
					}
				} );
			} );

		}

		// update like counter: start function
		updateLikeCounter();


		/**
		 * Social share buttons
		 * ----------------------------------------------------
		 */

		// function: prevent default action
		function preventDefaultOnShare() {

			var $shareIcon = $( '.bwp-post-share-icon' );

			// share icon: click
			$shareIcon.on( 'click', function( e ) {
				e.preventDefault();
			} );

		}

		// prevent default action: start function
		preventDefaultOnShare();

	} );
} )( jQuery );
