<?php
/**
 * Additional contact information
 *
 * @since Nimbo Social Media 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Add new user contact fields to the profile page: Users > Your Profile > Contact Info
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_new_contact_fields( $user_contact ) {

	// twitter
	if ( ! isset( $user_contact['twitter'] ) ) {
		$user_contact['twitter'] = esc_html__( 'Twitter URL', 'nimbo-social-media' );
	}

	// facebook
	if ( ! isset( $user_contact['facebook-f'] ) ) {
		$user_contact['facebook-f'] = esc_html__( 'Facebook URL', 'nimbo-social-media' );
	}

	// pinterest
	if ( ! isset( $user_contact['pinterest-p'] ) ) {
		$user_contact['pinterest-p'] = esc_html__( 'Pinterest URL', 'nimbo-social-media' );
	}

	// vk
	if ( ! isset( $user_contact['vk'] ) ) {
		$user_contact['vk'] = esc_html__( 'VK URL', 'nimbo-social-media' );
	}

	// telegram
	if ( ! isset( $user_contact['telegram-plane'] ) ) {
		$user_contact['telegram-plane'] = esc_html__( 'Telegram URL', 'nimbo-social-media' );
	}

	// flickr
	if ( ! isset( $user_contact['flickr'] ) ) {
		$user_contact['flickr'] = esc_html__( 'Flickr URL', 'nimbo-social-media' );
	}

	// instagram
	if ( ! isset( $user_contact['instagram'] ) ) {
		$user_contact['instagram'] = esc_html__( 'Instagram URL', 'nimbo-social-media' );
	}

	// 500px
	if ( ! isset( $user_contact['500px'] ) ) {
		$user_contact['500px'] = esc_html__( '500px URL', 'nimbo-social-media' );
	}

	// youtube
	if ( ! isset( $user_contact['youtube'] ) ) {
		$user_contact['youtube'] = esc_html__( 'YouTube URL', 'nimbo-social-media' );
	}

	// vimeo
	if ( ! isset( $user_contact['vimeo-v'] ) ) {
		$user_contact['vimeo-v'] = esc_html__( 'Vimeo URL', 'nimbo-social-media' );
	}

	// soundcloud
	if ( ! isset( $user_contact['soundcloud'] ) ) {
		$user_contact['soundcloud'] = esc_html__( 'Soundcloud URL', 'nimbo-social-media' );
	}

	// dribbble
	if ( ! isset( $user_contact['dribbble'] ) ) {
		$user_contact['dribbble'] = esc_html__( 'Dribbble URL', 'nimbo-social-media' );
	}

	// behance
	if ( ! isset( $user_contact['behance'] ) ) {
		$user_contact['behance'] = esc_html__( 'Behance URL', 'nimbo-social-media' );
	}

	// github
	if ( ! isset( $user_contact['github'] ) ) {
		$user_contact['github'] = esc_html__( 'GitHub URL', 'nimbo-social-media' );
	}

	return $user_contact;

}
add_filter( 'user_contactmethods', 'nimbo_social_media_new_contact_fields' );


/**
 * Show new social links on the author's page (page heading)
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_author_links() {

	// list of social links
	$social_list = array(
		'twitter',
		'facebook-f',
		'pinterest-p',
		'vk',
		'telegram-plane',
		'flickr',
		'instagram',
		'500px',
		'youtube',
		'vimeo-v',
		'soundcloud',
		'dribbble',
		'behance',
		'github',
	);

	// get all URLs
	$social_url = array();
	foreach ( $social_list as $social_list_value ) {
		$social_url[ $social_list_value ] = get_the_author_meta( $social_list_value ); // result: 'twitter' => 'twitter URL', 'facebook-f' => 'facebook URL', ...
	}

	// check $social_url
	$social_url_empty = true;
	foreach ( $social_url as $social_url_value ) {
		if ( $social_url_value ) {
			$social_url_empty = false;
			break;
		}
	}

	// show social links
	if ( ! $social_url_empty ) {
		?>
		<div class="bwp-author-heading-social-links">
			<span><?php esc_html_e( 'Follow:', 'nimbo-social-media' ); ?></span>
			<ul class="list-unstyled">
				<?php
				foreach ( $social_url as $social_url_key => $social_url_value ) {
					if ( $social_url_value ) {
						echo '<li><a href="' . esc_url( $social_url_value ) . '" target="_blank" rel="noopener" class="bwp-ah-' . esc_attr( $social_url_key ) . '-link"><i class="fab fa-' . esc_attr( $social_url_key ) . '"></i></a></li>';
					}
				}
				?>
			</ul>
		</div>
		<?php
	}

}
