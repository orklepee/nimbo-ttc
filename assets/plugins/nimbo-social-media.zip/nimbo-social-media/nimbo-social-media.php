<?php
/*
Plugin Name:	Nimbo Social Media
Plugin URI:		https://themeforest.net/user/birdwpthemes
Description:	This plugin provides the following social functions: "I like" counter for blog posts, comments counter, social share buttons, and additional social links for the author contact information.
Version:		1.1
Author:			Alexey Trofimov
Author URI:		https://themeforest.net/user/birdwpthemes
License:		GPL2
License URI:	https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:	nimbo-social-media
Domain Path:	/languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Define some constants
 *
 * @since Nimbo Social Media 1.0
 */
define( 'NIMBO_SOCIAL_MEDIA_DIR', plugin_dir_path( __FILE__ ) );
define( 'NIMBO_SOCIAL_MEDIA_URL', plugin_dir_url( __FILE__ ) );


/**
 * Make plugin available for translation
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_load_language_file() {

	// load language file; text domain = nimbo-social-media
	load_plugin_textdomain( 'nimbo-social-media', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

}
add_action( 'plugins_loaded', 'nimbo_social_media_load_language_file' );


/**
 * Enqueue scripts
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_scripts() {

	// nimbo social media: js
	wp_enqueue_script( 'nimbo-social-media-plugin', NIMBO_SOCIAL_MEDIA_URL . 'js/nimbo-social-media-plugin.js', array( 'jquery' ), '1.0.0', true );

	// nimbo social media: data for Ajax request
	$nimboSocialMediaData_array = array(
		'ajaxURL'	=> esc_url( admin_url( 'admin-ajax.php' ) ),
		'ajaxNonce'	=> wp_create_nonce( 'ajax-nonce' ),
	);
	wp_localize_script( 'nimbo-social-media-plugin', 'nimboSocialMediaData', $nimboSocialMediaData_array );

}
add_action( 'wp_enqueue_scripts', 'nimbo_social_media_scripts' );


/**
 * Add meta boxes
 *
 * @since Nimbo Social Media 1.0
 */
require_once NIMBO_SOCIAL_MEDIA_DIR . 'assets/plugin-meta-boxes.php';


/**
 * "I like" counter
 *
 * @since Nimbo Social Media 1.0
 */
require_once NIMBO_SOCIAL_MEDIA_DIR . 'post-like-counter.php';


/**
 * Comments counter
 *
 * @since Nimbo Social Media 1.0
 */
require_once NIMBO_SOCIAL_MEDIA_DIR . 'comments-counter.php';


/**
 * Add additional contact information
 *
 * @since Nimbo Social Media 1.0
 */
require_once NIMBO_SOCIAL_MEDIA_DIR . 'new-contact-info.php';


/**
 * Social share buttons
 *
 * @since Nimbo Social Media 1.0
 */
require_once NIMBO_SOCIAL_MEDIA_DIR . 'social-share-buttons.php';
