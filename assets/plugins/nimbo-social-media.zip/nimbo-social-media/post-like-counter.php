<?php
/*
Name: WordPress Post Like System
Description: A simple and efficient post like system for WordPress.
Version: 0.2
Author: Jon Masterson
Author URI: http://jonmasterson.com/

License:
Copyright (C) 2014 Jon Masterson

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Save like data
 *
 * @since Nimbo Social Media 1.0
 */

add_action( 'wp_ajax_nopriv_nimbo-social-media-like', 'nimbo_social_media_like' );
add_action( 'wp_ajax_nimbo-social-media-like', 'nimbo_social_media_like' );

function nimbo_social_media_like() {

	if ( isset( $_POST['nonce'] ) ) {
		$nonce = $_POST['nonce'];
		if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) ) {
			return;
		}
	} else {
		return;
	}

	if ( isset( $_POST['nimbo_social_media_like'] ) ) {

		if ( isset( $_POST['post_id'] ) ) {
			$post_id = $_POST['post_id']; // post id
		} else {
			return;
		}

		$post_like_count = get_post_meta( $post_id, '_nimbo_social_media_like_count', true ); // post like count
		$ip = $_SERVER['REMOTE_ADDR']; // user IP address
		$meta_IPS = get_post_meta( $post_id, '_nimbo_social_media_user_IP' ); // stored IP addresses
		$liked_IPS = '';

		if ( 0 !== count( $meta_IPS ) ) { // meta exists, set up values
			$liked_IPS = $meta_IPS[0];
		}

		if ( ! is_array( $liked_IPS ) ) { // make array just in case
			$liked_IPS = array();
		}

		if ( ! in_array( $ip, $liked_IPS ) ) { // if IP not in array
			$liked_IPS[ 'ip-' . $ip ] = $ip; // add IP to array
		}

		if ( ! nimbo_social_media_already_liked( $post_id ) ) { // like the post

			update_post_meta( $post_id, '_nimbo_social_media_user_IP', $liked_IPS ); // add user IP to post meta
			update_post_meta( $post_id, '_nimbo_social_media_like_count', ++$post_like_count ); // +1 count post meta
			echo (int) $post_like_count; // update count on front end

		} else { // unlike the post

			$ip_key = array_search( $ip, $liked_IPS ); // find the key
			unset( $liked_IPS[ $ip_key ] ); // remove from array
			update_post_meta( $post_id, '_nimbo_social_media_user_IP', $liked_IPS ); // remove user IP from post meta
			update_post_meta( $post_id, '_nimbo_social_media_like_count', --$post_like_count ); // -1 count post meta
			echo 'already' . (int) $post_like_count; // update count on front end

		}

	}

	wp_die();

}


/**
 * Test if user already liked post
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_already_liked( $post_id ) { // test if user liked before

	$meta_IPS = get_post_meta( $post_id, '_nimbo_social_media_user_IP' ); // get previously voted IP address
	$ip = $_SERVER['REMOTE_ADDR']; // retrieve current user IP
	$liked_IPS = '';

	if ( 0 !== count( $meta_IPS ) ) { // meta exists, set up values
		$liked_IPS = $meta_IPS[0];
	}

	if ( ! is_array( $liked_IPS ) ) { // make array just in case
		$liked_IPS = array();
	}

	if ( in_array( $ip, $liked_IPS ) ) { // true if IP in array
		return true;
	}

	return false;

}


/**
 * Get front end button
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_get_like( $post_id ) {

	$like_count = get_post_meta( $post_id, '_nimbo_social_media_like_count', true ); // get post likes

	if ( ( ! $like_count ) || ( $like_count && '0' === $like_count ) ) { // no votes, set up empty variable
		$likes = '0';
	} elseif ( $like_count && '0' !== $like_count ) { // there are votes!
		$likes = $like_count;
	}

	$output = '<span class="bwp-post-like-icon">';
	$output .= '<a rel="nofollow" href="#" data-post_id="' . (int) $post_id . '">';

	if ( nimbo_social_media_already_liked( $post_id ) ) { // already liked, set up unlike addon
		$output .= '<span class="bwp-like bwp-prevliked"><i class="fas fa-heart"></i></span>';
		$output .= '<span class="bwp-count bwp-alreadyliked">' . (int) $likes . '</span></a></span>';
	} else { // normal like button
		$output .= '<span class="bwp-like"><i class="far fa-heart"></i></span>';
		$output .= '<span class="bwp-count">' . (int) $likes . '</span></a></span>';
	}

	return $output;

}


/**
 * Get counter value
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_get_like_count( $post_id ) {

	$like_count = get_post_meta( $post_id, '_nimbo_social_media_like_count', true ); // get post likes

	return (int) $like_count;

}
