=== Nimbo Social Media ===
Contributors: BirdwpThemes
Tags: social, counters, share, contact
Requires at least: WordPress 4.9.x
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin provides the following social functions: 'I like' counter for blog posts, comments counter, social share buttons, and additional social links for the author contact information.

== Changelog ==
Version 1.1
- Removed all Google+ buttons:
  - Users > Your Profile > Google+ URL
  - Removed Google+ share button
- Added VK share button
- Added Reddit share button
- The rel="noopener" attribute has been added to all links that have the target="_blank" attribute
- Updated: Translation files

Version 1.0
- Release
