<?php
/**
 * Social share buttons
 *
 * @since Nimbo Social Media 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Show social share buttons on posts
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_post_share() {

	// post data: url, title, and image url
	$share_url = get_permalink(); // url
	$share_title = get_the_title(); // title
	$share_media = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' ); // image url
	?>

	<!-- share -->
	<div class="bwp-post-share">
		<a href="#" rel="nofollow" class="bwp-post-share-icon">
			<i class="fas fa-share-alt"></i>
		</a>
		<div class="bwp-post-share-list-wrap">
			<ul class="bwp-post-share-list list-unstyled clearfix">
				<!-- twitter -->
				<li>
					<a href="https://twitter.com/share?url=<?php echo esc_url( $share_url ); ?>&text=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-twitter-share" onclick="window.open('https://twitter.com/share?url=<?php echo esc_url( $share_url ); ?>&text=<?php echo rawurlencode( $share_title ); ?>', 'Twitter', 'width=700,height=500,left='+(screen.availWidth/2-350)+',top='+(screen.availHeight/2-250)+''); return false;">
						<i class="fab fa-twitter"></i>
					</a>
				</li>
				<!-- end: twitter -->
				<!-- facebook -->
				<li>
					<a href="https://www.facebook.com/sharer.php?u=<?php echo esc_url( $share_url ); ?>&t=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-facebook-share" onclick="window.open('https://www.facebook.com/sharer.php?u=<?php echo esc_url( $share_url ); ?>&t=<?php echo rawurlencode( $share_title ); ?>', 'Facebook', 'width=700,height=500,left='+(screen.availWidth/2-350)+',top='+(screen.availHeight/2-250)+''); return false;">
						<i class="fab fa-facebook-f"></i>
					</a>
				</li>
				<!-- end: facebook -->
				<!-- pinterest -->
				<li>
					<a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url( $share_url ); ?>&media=<?php if ( $share_media ) { echo esc_url( $share_media ); } else { echo ''; } ?>&description=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-pinterest-share" onclick="window.open('http://pinterest.com/pin/create/button/?url=<?php echo esc_url( $share_url ); ?>&media=<?php if ( $share_media ) { echo esc_url( $share_media ); } else { echo ''; } ?>&description=<?php echo rawurlencode( $share_title ); ?>', 'Pinterest', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
						<i class="fab fa-pinterest-p"></i>
					</a>
				</li>
				<!-- end: pinterest -->
				<!-- vk -->
				<li>
					<a href="https://vk.com/share.php?url=<?php echo esc_url( $share_url ); ?>" rel="nofollow noopener" target="_blank" class="bwp-vk-share" onclick="window.open('https://vk.com/share.php?url=<?php echo esc_url( $share_url ); ?>', 'VK', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
						<i class="fab fa-vk"></i>
					</a>
				</li>
				<!-- end: vk -->
				<!-- reddit -->
				<li>
					<a href="https://www.reddit.com/submit?url=<?php echo esc_url( $share_url ); ?>&title=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-reddit-share" onclick="window.open('https://www.reddit.com/submit?url=<?php echo esc_url( $share_url ); ?>&title=<?php echo rawurlencode( $share_title ); ?>', 'Reddit', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
						<i class="fab fa-reddit-alien"></i>
					</a>
				</li>
				<!-- end: reddit -->
			</ul>
		</div>
	</div>
	<!-- end: share -->

	<?php
}


/**
 * Show social share buttons on single pages
 *
 * @since Nimbo Social Media 1.0
 */
function nimbo_social_media_single_post_share() {

	// post data: url, title, and image url
	$share_url = get_permalink(); // url
	$share_title = get_the_title(); // title
	$share_media = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' ); // image url
	?>

	<!-- share -->
	<div class="bwp-single-post-share">
		<span><?php esc_html_e( 'Share', 'nimbo-social-media' ); ?></span>
		<ul class="bwp-single-post-share-list list-unstyled">
			<!-- twitter -->
			<li>
				<a href="https://twitter.com/share?url=<?php echo esc_url( $share_url ); ?>&text=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-twitter-share" onclick="window.open('https://twitter.com/share?url=<?php echo esc_url( $share_url ); ?>&text=<?php echo rawurlencode( $share_title ); ?>', 'Twitter', 'width=700,height=500,left='+(screen.availWidth/2-350)+',top='+(screen.availHeight/2-250)+''); return false;">
					<i class="fab fa-twitter"></i>
				</a>
			</li>
			<!-- end: twitter -->
			<!-- facebook -->
			<li>
				<a href="https://www.facebook.com/sharer.php?u=<?php echo esc_url( $share_url ); ?>&t=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-facebook-share" onclick="window.open('https://www.facebook.com/sharer.php?u=<?php echo esc_url( $share_url ); ?>&t=<?php echo rawurlencode( $share_title ); ?>', 'Facebook', 'width=700,height=500,left='+(screen.availWidth/2-350)+',top='+(screen.availHeight/2-250)+''); return false;">
					<i class="fab fa-facebook-f"></i>
				</a>
			</li>
			<!-- end: facebook -->
			<!-- pinterest -->
			<li>
				<a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url( $share_url ); ?>&media=<?php if ( $share_media ) { echo esc_url( $share_media ); } else { echo ''; } ?>&description=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-pinterest-share" onclick="window.open('http://pinterest.com/pin/create/button/?url=<?php echo esc_url( $share_url ); ?>&media=<?php if ( $share_media ) { echo esc_url( $share_media ); } else { echo ''; } ?>&description=<?php echo rawurlencode( $share_title ); ?>', 'Pinterest', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
					<i class="fab fa-pinterest-p"></i>
				</a>
			</li>
			<!-- end: pinterest -->
			<!-- vk -->
			<li>
				<a href="https://vk.com/share.php?url=<?php echo esc_url( $share_url ); ?>" rel="nofollow noopener" target="_blank" class="bwp-vk-share" onclick="window.open('https://vk.com/share.php?url=<?php echo esc_url( $share_url ); ?>', 'VK', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
					<i class="fab fa-vk"></i>
				</a>
			</li>
			<!-- end: vk -->
			<!-- reddit -->
			<li>
				<a href="https://www.reddit.com/submit?url=<?php echo esc_url( $share_url ); ?>&title=<?php echo rawurlencode( $share_title ); ?>" rel="nofollow noopener" target="_blank" class="bwp-reddit-share" onclick="window.open('https://www.reddit.com/submit?url=<?php echo esc_url( $share_url ); ?>&title=<?php echo rawurlencode( $share_title ); ?>', 'Reddit', 'width=800,height=700,left='+(screen.availWidth/2-400)+',top='+(screen.availHeight/2-350)+''); return false;">
					<i class="fab fa-reddit-alien"></i>
				</a>
			</li>
			<!-- end: reddit -->
		</ul>
	</div>
	<!-- end: share -->

	<?php
}
