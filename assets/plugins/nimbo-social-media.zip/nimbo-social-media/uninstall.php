<?php
/**
 * Plugin removal file
 *
 * @since Nimbo Social Media 1.0
 */

// if uninstall not called from WordPress, then exit
if ( ! defined( 'ABSPATH' ) && ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// if not allowed to delete plugins go to plugins page
if ( ! current_user_can( 'delete_plugins' ) ) {
	wp_die( esc_html__( 'Sorry, you are not allowed to delete plugins for this site.', 'nimbo-social-media' ) );
}


/**
 * Delete all data of the "I like" counter
 *
 * @since Nimbo Social Media 1.0
 */

// get all posts
$all_posts = get_posts( 'numberposts=-1&post_type=post&post_status=any' );

// delete all metadata of all posts
foreach( $all_posts as $post_info ) {
	delete_post_meta( $post_info->ID, '_nimbo_social_media_user_IP' );
	delete_post_meta( $post_info->ID, '_nimbo_social_media_like_count' );
}

// reset postdata
wp_reset_postdata();


/**
 * Delete all additional metadata of all pages
 *
 * @since Nimbo Social Media 1.0
 */

// get all pages
$all_pages = get_posts( 'numberposts=-1&post_type=page&post_status=any' );

// delete all metadata of all pages
foreach( $all_pages as $page_info ) {
	delete_post_meta( $page_info->ID, 'nimbo_social_media_page_show_share_buttons' );
}

// reset postdata
wp_reset_postdata();
