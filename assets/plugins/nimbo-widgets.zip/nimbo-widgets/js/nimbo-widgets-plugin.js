/**
 * Plugin name: Nimbo Widgets
 * nimbo-widgets-plugin.js v1.0.0
 */

( function( $ ) {
	'use strict';
	$( document ).ready( function() {

		/**
		 * Widget: Posts slider (owlCarousel)
		 * ----------------------------------------------------
		 */

		// initialize owlCarousel
		$( '.widget-bwp-init-posts-slider' ).owlCarousel( {
			items: 1,
			autoHeight: true,
			loop: false,
			nav: true,
			rewind: true,
			navText: [ "<i class='fas fa-caret-left'></i>", "<i class='fas fa-caret-right'></i>" ],
			dots: false,
			autoplay: false,
			autoplayTimeout: 10000,
			autoplayHoverPause: true,
			autoplaySpeed: 300,
			navSpeed: 300,
			dragEndSpeed: 300
		} );

	} );
} )( jQuery );
