<?php
/*
Plugin Name:	Nimbo Widgets
Plugin URI:		https://themeforest.net/user/birdwpthemes
Description:	This plugin provides a set of 5 additional widgets.
Version:		1.0.2
Author:			Alexey Trofimov
Author URI:		https://themeforest.net/user/birdwpthemes
License:		GPL2
License URI:	https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:	nimbo-widgets
Domain Path:	/languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Define some constants
 *
 * @since Nimbo Widgets 1.0
 */
define( 'NIMBO_WIDGETS_DIR', plugin_dir_path( __FILE__ ) );
define( 'NIMBO_WIDGETS_URL', plugin_dir_url( __FILE__ ) );


/**
 * Make plugin available for translation
 *
 * @since Nimbo Widgets 1.0
 */
function nimbo_widgets_load_language_file() {

	// load language file; text domain = nimbo-widgets
	load_plugin_textdomain( 'nimbo-widgets', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

}
add_action( 'plugins_loaded', 'nimbo_widgets_load_language_file' );


/**
 * Enqueue scripts and styles
 *
 * @since Nimbo Widgets 1.0
 */
function nimbo_widgets_scripts_styles() {

	// owl carousel: css
	wp_enqueue_style( 'owl-carousel', NIMBO_WIDGETS_URL . 'assets/owlcarousel/assets/owl.carousel.min.css', array(), '2.3.4' );
	wp_enqueue_style( 'owl-theme-default', NIMBO_WIDGETS_URL . 'assets/owlcarousel/assets/owl.theme.default.min.css', array(), '2.3.4' );

	// owl carousel: js
	wp_enqueue_script( 'owl-carousel', NIMBO_WIDGETS_URL . 'assets/owlcarousel/owl.carousel.min.js', array( 'jquery' ), '2.3.4', true );

	// nimbo widgets: js
	wp_enqueue_script( 'nimbo-widgets-plugin', NIMBO_WIDGETS_URL . 'js/nimbo-widgets-plugin.js', array( 'jquery' ), '1.0.0', true );

}
add_action( 'wp_enqueue_scripts', 'nimbo_widgets_scripts_styles' );


/**
 * Add widgets
 *
 * @since Nimbo Widgets 1.0
 */
require_once NIMBO_WIDGETS_DIR . 'widget-list-of-posts.php';
require_once NIMBO_WIDGETS_DIR . 'widget-popular-posts.php';
require_once NIMBO_WIDGETS_DIR . 'widget-random-posts.php';
require_once NIMBO_WIDGETS_DIR . 'widget-recent-posts.php';
require_once NIMBO_WIDGETS_DIR . 'widget-slider-with-posts.php';
