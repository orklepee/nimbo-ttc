=== Nimbo Widgets ===
Contributors: BirdwpThemes
Tags: widget, widgets, list-of-posts, popular-posts, random-posts, recent-posts, slider, slider-with-posts
Requires at least: WordPress 4.9.x
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin provides a set of 5 additional widgets.

== Changelog ==
Version 1.0.2
- Some minor changes
- Updated: Translation files

Version 1.0.1
- Updated: Owl Carousel 2 (Version 2.3.4)

Version 1.0
- Release
