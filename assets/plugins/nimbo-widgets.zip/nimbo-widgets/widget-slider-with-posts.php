<?php
/**
 * Widget: Slider With Posts
 *
 * @since Nimbo Widgets 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Register widget
 */
add_action( 'widgets_init', 'nimbo_widgets_register_posts_slider_widget' );

function nimbo_widgets_register_posts_slider_widget() {
	register_widget( 'nimbo_widgets_posts_slider_widget' );
}


/**
 * Class nimbo_widgets_posts_slider_widget
 */
class nimbo_widgets_posts_slider_widget extends WP_Widget {

	/**
	 * Sets up the widget name, description, class, etc
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'		=> 'widget_bwp_posts_slider',
			'description'	=> esc_html__( 'Displays a slider with posts.', 'nimbo-widgets' ),
		);
		parent::__construct( 'nimbo_posts_slider_widget', esc_html__( 'Nimbo: Slider With Posts', 'nimbo-widgets' ), $widget_ops );
	}

	/**
	 * Outputs the options form on admin
	 */
	public function form( $instance ) {
		// defaults
		$title_instance = isset( $instance['title'] ) ? sanitize_text_field( $instance['title'] ) : '';
		$num_posts_instance = isset( $instance['num_posts'] ) ? $instance['num_posts'] : 4;
		$show_author_instance = isset( $instance['show_author'] ) ? (bool) $instance['show_author'] : false;
		$show_date_instance = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		$categories_instance = isset( $instance['categories'] ) ? $instance['categories'] : '';
		$show_random_instance = isset( $instance['show_random'] ) ? (bool) $instance['show_random'] : false;
		?>

		<!-- title -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'nimbo-widgets' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title_instance ); ?>">
		</p>
		<!-- end: title -->

		<!-- posts number -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'num_posts' ) ); ?>"><?php esc_html_e( 'Posts number:', 'nimbo-widgets' ); ?></label>
			<input type="number" min="1" max="40" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'num_posts' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'num_posts' ) ); ?>" value="<?php echo (int) $num_posts_instance; ?>">
		</p>
		<!-- end: posts number -->

		<!-- show author -->
		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_author' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_author' ) ); ?>"<?php checked( $show_author_instance ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'show_author' ) ); ?>"><?php esc_html_e( 'Show author', 'nimbo-widgets' ); ?></label>
		</p>
		<!-- end: show author -->

		<!-- show date -->
		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>"<?php checked( $show_date_instance ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php esc_html_e( 'Show date', 'nimbo-widgets' ); ?></label>
		</p>
		<!-- end: show date -->

		<!-- categories -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'categories' ) ); ?>"><?php esc_html_e( 'Filter by category:', 'nimbo-widgets' ); ?></label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'categories' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'categories' ) ); ?>" class="widefat">
				<option value="" <?php if ( '' === $categories_instance ) { echo 'selected="selected"'; } ?>><?php esc_html_e( 'All categories', 'nimbo-widgets' ); ?></option>
				<?php
				$posts_categories = get_categories( 'hide_empty=0&depth=1&type=post' );
				foreach ( $posts_categories as $category ) {
					$category_id = $category->term_id;
					$category_name = $category->cat_name;
					?>
					<option value="<?php echo (int) $category_id; ?>" <?php if ( $category_id === (int) $categories_instance ) { echo 'selected="selected"'; } ?>><?php echo esc_html( $category_name ); ?></option>
					<?php
				}
				?>
			</select>
		</p>
		<!-- end: categories -->

		<!-- show random -->
		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_random' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_random' ) ); ?>"<?php checked( $show_random_instance ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'show_random' ) ); ?>"><?php esc_html_e( 'Random order', 'nimbo-widgets' ); ?></label>
		</p>
		<!-- end: show random -->

		<?php
	}

	/**
	 * Processing widget options on save
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['num_posts'] = (int) $new_instance['num_posts'];
		$instance['show_author'] = isset( $new_instance['show_author'] ) ? (bool) $new_instance['show_author'] : false;
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$instance['categories'] = $new_instance['categories'];
		$instance['show_random'] = isset( $new_instance['show_random'] ) ? (bool) $new_instance['show_random'] : false;

		return $instance;
	}

	/**
	 * Outputs the content of the widget
	 */
	public function widget( $args, $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Slider with posts', 'nimbo-widgets' );
		$num_posts = ! empty( $instance['num_posts'] ) ? (int) $instance['num_posts'] : 4;
		if ( ! $num_posts ) {
			$num_posts = 4;
		}
		$show_author = isset( $instance['show_author'] ) ? $instance['show_author'] : false;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;
		$categories = ! empty( $instance['categories'] ) ? $instance['categories'] : '';
		$show_random = isset( $instance['show_random'] ) ? $instance['show_random'] : false;

		// order by
		if ( $show_random ) {
			$orderby = 'rand';
		} else {
			$orderby = 'date';
		}

		// display "aside" tag
		echo wp_kses( $args['before_widget'], array(
			'aside' => array(
				'id'	=> array(),
				'class'	=> array(),
			),
		) );

		// display widget title
		if ( $title ) {
			echo wp_kses( $args['before_title'], array(
				'h3' => array(
					'class' => array(),
				),
			) );
			echo esc_html( $title );
			echo wp_kses( $args['after_title'], array( 'h3' => array() ) );
		}

		// query args
		$slider_args = array(
			'posts_per_page'		=> $num_posts,
			'post_type'				=> 'post',
			'cat'					=> $categories,
			'orderby'				=> $orderby,
			'ignore_sticky_posts'	=> true,
		);
		$slider_query = new WP_Query( $slider_args );

		// start widget
		if ( $slider_query->have_posts() ) :

			// image size
			$image_size = 'nimbo-939x626-crop';

			echo '<div class="widget-bwp-posts-slider-wrap"><div class="owl-carousel owl-theme widget-bwp-init-posts-slider">';

			while ( $slider_query->have_posts() ) : $slider_query->the_post();

				// featured image
				if ( has_post_thumbnail() ) {
					?>

					<figure class="widget_bwp_posts_slider_item">
						<?php the_post_thumbnail( $image_size ); ?>
						<div class="widget_bwp_dark_bg_overlay"></div>
						<figcaption>

							<?php if ( get_the_title() ) { ?>
								<h4 class="entry-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h4>
							<?php } else { ?>
								<h4 class="entry-title">
									<a href="<?php the_permalink(); ?>"><?php esc_html_e( 'View post', 'nimbo-widgets' ); ?></a>
								</h4>
							<?php } ?>

							<?php if ( $show_author || $show_date ) { ?>
								<ul class="widget_bwp_meta list-unstyled clearfix">
									<?php if ( $show_author ) { ?>
										<li>
											<?php
											$author_id = get_the_author_meta( 'ID' );
											$author_display_name = get_the_author_meta( 'display_name' );
											$author_posts_url = get_author_posts_url( $author_id );
											?>
											<a href="<?php echo esc_url( $author_posts_url ); ?>" title="<?php echo esc_attr__( 'Posts by', 'nimbo-widgets' ) . ' ' . esc_attr( $author_display_name ); ?>" rel="author">
												<span class="vcard author">
													<span class="fn"><?php echo esc_html( $author_display_name ); ?></span>
												</span>
											</a>
										</li>
									<?php } ?>
									<?php if ( $show_date ) { ?>
										<li>
											<?php
											$archive_year = get_the_time( 'Y' );
											$archive_month = get_the_time( 'm' );
											$archive_day = get_the_time( 'd' );
											?>
											<a href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>">
												<span class="date updated"><?php the_time( get_option( 'date_format' ) ); ?></span>
											</a>
										</li>
									<?php } ?>
								</ul>
							<?php } ?>

						</figcaption>
					</figure>

					<?php
				} else { // gallery image

					// gallery images ID
					$gallery_images_id = get_post_meta( get_the_ID(), 'nimbo_mb_gallery', false );
					if ( ! is_array( $gallery_images_id ) ) {
						$gallery_images_id = (array) $gallery_images_id;
					}
					if ( ! empty( $gallery_images_id ) && $gallery_images_id[0] ) {
						$gallery_image_url = wp_get_attachment_image_url( $gallery_images_id[0], $image_size );
						$gallery_image_alt = get_post_meta( $gallery_images_id[0], '_wp_attachment_image_alt', true );
						?>

						<figure class="widget_bwp_posts_slider_item">
							<img src="<?php echo esc_url( $gallery_image_url ); ?>" alt="<?php if ( $gallery_image_alt ) { echo esc_attr( $gallery_image_alt ); } else { the_title_attribute(); } ?>">
							<div class="widget_bwp_dark_bg_overlay"></div>
							<figcaption>

								<?php if ( get_the_title() ) { ?>
									<h4 class="entry-title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h4>
								<?php } else { ?>
									<h4 class="entry-title">
										<a href="<?php the_permalink(); ?>"><?php esc_html_e( 'View post', 'nimbo-widgets' ); ?></a>
									</h4>
								<?php } ?>

								<?php if ( $show_author || $show_date ) { ?>
									<ul class="widget_bwp_meta list-unstyled clearfix">
										<?php if ( $show_author ) { ?>
											<li>
												<?php
												$author_id = get_the_author_meta( 'ID' );
												$author_display_name = get_the_author_meta( 'display_name' );
												$author_posts_url = get_author_posts_url( $author_id );
												?>
												<a href="<?php echo esc_url( $author_posts_url ); ?>" title="<?php echo esc_attr__( 'Posts by', 'nimbo-widgets' ) . ' ' . esc_attr( $author_display_name ); ?>" rel="author">
													<span class="vcard author">
														<span class="fn"><?php echo esc_html( $author_display_name ); ?></span>
													</span>
												</a>
											</li>
										<?php } ?>
										<?php if ( $show_date ) { ?>
											<li>
												<?php
												$archive_year = get_the_time( 'Y' );
												$archive_month = get_the_time( 'm' );
												$archive_day = get_the_time( 'd' );
												?>
												<a href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>">
													<span class="date updated"><?php the_time( get_option( 'date_format' ) ); ?></span>
												</a>
											</li>
										<?php } ?>
									</ul>
								<?php } ?>

							</figcaption>
						</figure>

						<?php
					}

				}

			endwhile;

			echo '</div><!-- /owl-carousel --></div><!-- /widget-bwp-posts-slider-wrap -->';

		endif;
		// end: widget

		// if no posts
		if ( ! $slider_query->have_posts() ) :
			?>

			<p class="widget_bwp_no_posts">
				<?php esc_html_e( 'No posts found.', 'nimbo-widgets' ); ?>
			</p>

			<?php
		endif;

		// reset post data
		wp_reset_postdata();

		// display "aside" tag
		echo wp_kses( $args['after_widget'], array( 'aside' => array() ) );
	}

}
